/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkomniscraper_frontend"] = self["webpackChunkomniscraper_frontend"] || []).push([["main"],{

/***/ 2352:
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
/***/ (() => {

eval("throw new Error(\"Module build failed (from ./node_modules/babel-loader/lib/index.js):\\nSyntaxError: C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\src\\\\index.js: Unexpected token, expected \\\",\\\" (8:2)\\n\\n\\u001b[0m \\u001b[90m  6 |\\u001b[39m \\u001b[33mReactDOM\\u001b[39m\\u001b[33m.\\u001b[39mrender(\\u001b[0m\\n\\u001b[0m \\u001b[90m  7 |\\u001b[39m     \\u001b[33m<\\u001b[39m\\u001b[33mApp\\u001b[39m \\u001b[33m/\\u001b[39m\\u001b[33m>\\u001b[39m\\u001b[0m\\n\\u001b[0m\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m  8 |\\u001b[39m   document\\u001b[33m.\\u001b[39mgetElementById(\\u001b[32m\\\"app\\\"\\u001b[39m)\\u001b[0m\\n\\u001b[0m \\u001b[90m    |\\u001b[39m   \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m  9 |\\u001b[39m )\\u001b[33m;\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 10 |\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 11 |\\u001b[39m \\u001b[36mif\\u001b[39m (\\u001b[32m\\\"serviceWorker\\\"\\u001b[39m \\u001b[36min\\u001b[39m navigator) {\\u001b[0m\\n    at Object._raise (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:816:17)\\n    at Object.raiseWithData (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:809:17)\\n    at Object.raise (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:770:17)\\n    at Object.unexpected (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:9893:16)\\n    at Object.expect (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:9867:28)\\n    at Object.parseCallExpressionArguments (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:11069:14)\\n    at Object.parseCoverCallAndAsyncArrowHead (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:10992:29)\\n    at Object.parseSubscript (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:10925:19)\\n    at Object.parseSubscripts (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:10898:19)\\n    at Object.parseExprSubscripts (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:10887:17)\");\n\n//# sourceURL=webpack://omniscraper_frontend/./src/index.js?");

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ "use strict";
/******/ 
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ var __webpack_exports__ = (__webpack_exec__(2352));
/******/ }
]);