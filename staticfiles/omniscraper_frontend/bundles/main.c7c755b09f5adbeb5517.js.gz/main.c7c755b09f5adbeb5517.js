/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkomniscraper_frontend"] = self["webpackChunkomniscraper_frontend"] || []).push([["main"],{

/***/ 624:
/*!*******************************!*\
  !*** ./src/components/App.js ***!
  \*******************************/
/***/ (() => {

eval("throw new Error(\"Module build failed (from ./node_modules/babel-loader/lib/index.js):\\nSyntaxError: C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\src\\\\components\\\\App.js: Expected corresponding JSX closing tag for <Route>. (283:14)\\n\\n\\u001b[0m \\u001b[90m 281 |\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 282 |\\u001b[39m                 \\u001b[33m<\\u001b[39m\\u001b[33mRoute\\u001b[39m path\\u001b[33m=\\u001b[39m\\u001b[32m\\\"/:slug\\\"\\u001b[39m children\\u001b[33m=\\u001b[39m{\\u001b[33m<\\u001b[39m\\u001b[33mVideo\\u001b[39m \\u001b[35m/>} /\\u001b[39m\\u001b[33m>\\u001b[39m\\u001b[0m\\n\\u001b[0m\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 283 |\\u001b[39m               \\u001b[33m<\\u001b[39m\\u001b[33m/\\u001b[39m\\u001b[33mSwitch\\u001b[39m\\u001b[33m>\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m     |\\u001b[39m               \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 284 |\\u001b[39m             \\u001b[33m<\\u001b[39m\\u001b[33m/\\u001b[39m\\u001b[33mSuspense\\u001b[39m\\u001b[33m>\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 285 |\\u001b[39m           \\u001b[33m<\\u001b[39m\\u001b[33m/\\u001b[39m\\u001b[33mdiv\\u001b[39m\\u001b[33m>\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 286 |\\u001b[39m         \\u001b[33m<\\u001b[39m\\u001b[33m/\\u001b[39m\\u001b[33mThemeProvider\\u001b[39m\\u001b[33m>\\u001b[39m\\u001b[0m\\n    at Object._raise (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:816:17)\\n    at Object.raiseWithData (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:809:17)\\n    at Object.raise (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:770:17)\\n    at Object.jsxParseElementAt (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:5203:16)\\n    at Object.jsxParseElementAt (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:5171:32)\\n    at Object.jsxParseElementAt (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:5171:32)\\n    at Object.jsxParseElementAt (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:5171:32)\\n    at Object.jsxParseElementAt (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:5171:32)\\n    at Object.jsxParseElementAt (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:5171:32)\\n    at Object.jsxParseElement (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:5229:17)\");\n\n//# sourceURL=webpack://omniscraper_frontend/./src/components/App.js?");

/***/ }),

/***/ 2352:
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
eval("/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 7294);\n/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ 3935);\n/* harmony import */ var _components_App__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/App */ 624);\n/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./index.css */ 8548);\n\n\n\n\nreact_dom__WEBPACK_IMPORTED_MODULE_1__.render( /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_components_App__WEBPACK_IMPORTED_MODULE_2__.default, null), document.getElementById(\"app\"));\n\n//# sourceURL=webpack://omniscraper_frontend/./src/index.js?");

/***/ }),

/***/ 1424:
/*!*************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/index.css ***!
  \*************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ 3645);\n/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0__);\n// Imports\n\nvar ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_0___default()(function(i){return i[1]});\n// Module\n___CSS_LOADER_EXPORT___.push([module.id, \"*{\\r\\n    margin: 0;\\r\\n    padding: 0;\\r\\n}\\r\\n\\r\\nhtml, body {\\r\\n    font-family: \\\"Montserrat\\\", sans-serif;\\r\\n}\", \"\"]);\n// Exports\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);\n\n\n//# sourceURL=webpack://omniscraper_frontend/./src/index.css?./node_modules/css-loader/dist/cjs.js");

/***/ }),

/***/ 8548:
/*!***********************!*\
  !*** ./src/index.css ***!
  \***********************/
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
eval("/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ 3379);\n/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!./index.css */ 1424);\n\n            \n\nvar options = {};\n\noptions.insert = \"head\";\noptions.singleton = false;\n\nvar update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__.default, options);\n\n\n\n/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_1__.default.locals || {});\n\n//# sourceURL=webpack://omniscraper_frontend/./src/index.css?");

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ "use strict";
/******/ 
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendors"], () => (__webpack_exec__(2352)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);