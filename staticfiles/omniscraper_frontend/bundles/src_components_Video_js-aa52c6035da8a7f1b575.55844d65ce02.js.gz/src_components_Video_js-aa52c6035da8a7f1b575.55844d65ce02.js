/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunkomniscraper_frontend"] = self["webpackChunkomniscraper_frontend"] || []).push([["src_components_Video_js"],{

/***/ 1219:
/*!*********************************!*\
  !*** ./src/components/Video.js ***!
  \*********************************/
/***/ (() => {

eval("throw new Error(\"Module build failed (from ./node_modules/babel-loader/lib/index.js):\\nSyntaxError: C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\src\\\\components\\\\Video.js: Unexpected token (80:8)\\n\\n\\u001b[0m \\u001b[90m 78 |\\u001b[39m   }\\u001b[33m;\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 79 |\\u001b[39m\\u001b[0m\\n\\u001b[0m\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 80 |\\u001b[39m   \\u001b[36mconst\\u001b[39m parentTweetId \\u001b[33m=\\u001b[39m \\u001b[33mJSONbig\\u001b[39m\\u001b[33m.\\u001b[39mparse(video\\u001b[33m.\\u001b[39mparent_tweet_id)\\u001b[33m.\\u001b[39mtoString()\\u001b[0m\\n\\u001b[0m \\u001b[90m    |\\u001b[39m         \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 81 |\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 82 |\\u001b[39m   render() {\\u001b[0m\\n\\u001b[0m \\u001b[90m 83 |\\u001b[39m     \\u001b[36mconst\\u001b[39m { downloadVideo } \\u001b[33m=\\u001b[39m \\u001b[36mthis\\u001b[39m\\u001b[33m;\\u001b[39m\\u001b[0m\\n    at Object._raise (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:816:17)\\n    at Object.raiseWithData (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:809:17)\\n    at Object.raise (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:770:17)\\n    at Object.unexpected (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:9893:16)\\n    at Object.parseClassMemberWithIsStatic (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:13510:12)\\n    at Object.parseClassMember (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:13396:10)\\n    at C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:13341:14\\n    at Object.withTopicForbiddingContext (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:12303:14)\\n    at Object.parseClassBody (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:13318:10)\\n    at Object.parseClass (C:\\\\Users\\\\Frankie-fresh\\\\documents\\\\codes\\\\final\\\\omniscraper-web\\\\omniscraper_frontend\\\\node_modules\\\\@babel\\\\parser\\\\lib\\\\index.js:13292:22)\");\n\n//# sourceURL=webpack://omniscraper_frontend/./src/components/Video.js?");

/***/ })

}]);